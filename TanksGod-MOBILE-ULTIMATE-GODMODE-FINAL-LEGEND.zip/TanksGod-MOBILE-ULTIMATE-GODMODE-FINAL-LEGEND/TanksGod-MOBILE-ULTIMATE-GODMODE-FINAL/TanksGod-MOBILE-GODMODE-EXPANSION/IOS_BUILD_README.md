# TanksGod Chaos Ultimate iOS

Это подготовленная iOS-обертка через Capacitor.

## Сборка
1. Установить Node.js.
2. npm install
3. npx cap add ios
4. npx cap sync ios
5. Открыть проект в Xcode.
6. Подписать Apple Developer аккаунтом.
7. Build Archive -> iOS приложение.

Для публикации нужен Apple Developer аккаунт.
